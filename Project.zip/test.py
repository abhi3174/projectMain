a = ['a', 'b', 'c', 'd']
for i in a:
    a.append(i.upper())
print(a)
