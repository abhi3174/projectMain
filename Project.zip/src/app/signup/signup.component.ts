import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  signupForm = new FormGroup({
    userName: new FormControl('', [
      Validators.required,
      Validators.pattern("[a-zA-Z0-9]{6,18}")]),
    email: new FormControl('', [
      Validators.required,
      Validators.email]),
    firstName: new FormControl('', [
      Validators.required,
      Validators.pattern("[a-zA-Z0-9]{1,18}")]),
    lastName: new FormControl('', [
      Validators.required,
      Validators.pattern("[a-zA-Z0-9]{1,18}")]),
    passWord: new FormControl('', [
      Validators.required,
      Validators.pattern("[a-zA-Z0-9]{6,18}")]),
  });


  constructor(
    private http: HttpClient
  ) { }

  ngOnInit(): void {

  }
  async onSumbit() {
    const data = this.signupForm.value;
    const url = "http://localhost:5000/adduser"

    const result: any = await this.http.post(url, data).toPromise();
    window.alert(result.message)
    this.signupForm.reset();
  }

}


// async registerHere() {
//   const data = this.lgform.value;
//   console.log(data)
//   const url = "http://localhost:5000/adduser";

//   await this.http.post(url, data).toPromise();
//   window.alert("DONE")
//   //this.router.navigate(['login']);

// }














//https://stackoverflow.com/questions/12018245/regular-expression-to-validate-username/12019115 for regex