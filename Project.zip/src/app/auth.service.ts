import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  loggedInStatus: boolean = false;

  constructor(
    private http: HttpClient,
    private router: Router,
  ) { }

  setLoggedIn(value: any) {
    this.loggedInStatus = value;
  }

  get isLoggedIn() {
    return this.loggedInStatus;
  }

  async getUserDeatails(userName: any, passWord: any) {

    const url = "http://localhost:5000/loginuser"
    const data = { "userName": userName, "passWord": passWord };
    const result = await this.http.post(url, data).toPromise();

    return result;
  }
  login() {
    this.router.navigate(['login']);
  }
  logout() {
    this.setLoggedIn(false);
    this.router.navigate(['login']);
  }

}
