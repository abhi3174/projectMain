import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  isLoginMode: boolean = false;

  loginForm = new FormGroup({
    userName: new FormControl('', [
      Validators.required,
      Validators.pattern("[a-zA-Z0-9]{6,18}")]),

    passWord: new FormControl('', [
      Validators.required,
      Validators.pattern("[a-zA-Z0-9]{6,18}")]),
  });
  constructor(
    private http: HttpClient,
    private Auth: AuthService,
    private router: Router,
  ) { }


  ngOnInit(): void {
  }
  async onSumbit() {
    const data = this.loginForm.value;

    const result: any = await this.Auth.getUserDeatails(data.userName, data.passWord);


    this.loginForm.reset();

    if (result.c == true) {
      this.Auth.setLoggedIn(true);
      this.router.navigate(['home']);
      console.log(this.Auth.isLoggedIn)

    } else {
      window.alert("Please try again")
    }
  }

}
