import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    // const url = "http://kbcs.in:8080/englishlab/TenseAPI"
    // this.http.get(url).subscribe(data => {
    //   console.log(data);
    // })
  }

}
